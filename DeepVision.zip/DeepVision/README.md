# DeepVision Studio – Deep Learning Detection Project
Two detectors in one web UI:
1. **Digit Detector** – CNN trained from scratch on MNIST (convolution, pooling, softmax, backprop, mini-batch gradient descent).
2. **Object Detector** – MobileNetV2 transfer learning (1000 ImageNet classes) + **Grad-CAM** heatmap. Works with image upload or LIVE webcam.

## Run (Python 3.9 – 3.12, internet needed on first run)
    python -m venv venv
    venv\Scripts\activate          (Mac/Linux: source venv/bin/activate)
    pip install -r requirements.txt
    python app.py
Open http://127.0.0.1:5000
First run downloads MNIST and trains the digit CNN (~1-2 min); the model is saved in models/. MobileNetV2 weights download on first object detection.

## Files
app.py (models + API) | templates/index.html (UI) | requirements.txt
