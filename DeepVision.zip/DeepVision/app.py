"""DeepVision Studio - Deep Learning detection web app (Flask + TensorFlow/Keras)
1) Digit Detector : custom CNN trained from scratch on MNIST (conv -> pool -> flatten -> dense -> softmax,
                    mini-batch gradient descent / Adam, backprop)  -> same ideas as your Practical 2/6.
2) Object Detector: MobileNetV2 (transfer learning, ImageNet) + Grad-CAM heatmap showing WHERE the net looked.
"""
import os, io, base64
import numpy as np
from flask import Flask, request, jsonify, render_template
from PIL import Image
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions

app = Flask(__name__)
DIGIT_PATH = os.path.join("models", "digit_cnn.keras")
_digit, _det, _cam = None, None, None


def build_digit_cnn():
    return keras.Sequential([
        layers.Input((28, 28, 1)),
        layers.Conv2D(32, 3, activation="relu"), layers.MaxPooling2D(),
        layers.Conv2D(64, 3, activation="relu"), layers.MaxPooling2D(),
        layers.Flatten(), layers.Dropout(0.3),
        layers.Dense(128, activation="relu"),
        layers.Dense(10, activation="softmax")])


def digit_model():
    global _digit
    if _digit is None:
        if os.path.exists(DIGIT_PATH):
            _digit = keras.models.load_model(DIGIT_PATH)
        else:
            print(">>> First run: training digit CNN on MNIST (about 1-2 min)...")
            (xt, yt), (xv, yv) = keras.datasets.mnist.load_data()
            xt = (xt / 255.0).astype("float32")[..., None]; xv = (xv / 255.0).astype("float32")[..., None]
            m = build_digit_cnn()
            m.compile("adam", "sparse_categorical_crossentropy", metrics=["accuracy"])
            m.fit(xt, yt, epochs=4, batch_size=128, validation_data=(xv, yv), verbose=2)  # mini-batch GD
            m.save(DIGIT_PATH); _digit = m
    return _digit


def detector():
    global _det, _cam
    if _det is None:
        _det = MobileNetV2(weights="imagenet")
        _cam = keras.Model(_det.inputs, [_det.get_layer("out_relu").output, _det.output])
    return _det, _cam


def load_img(data_url):
    raw = base64.b64decode(data_url.split(",")[1])
    return Image.open(io.BytesIO(raw))


def prep_digit(img):
    """Canvas drawing -> centred 28x28 MNIST-style input."""
    img = img.convert("RGBA"); bg = Image.new("RGBA", img.size, (0, 0, 0, 255))
    g = np.array(Image.alpha_composite(bg, img).convert("L"))
    ys, xs = np.where(g > 30)
    if len(xs) == 0:
        return None
    g = g[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = g.shape; s = 20.0 / max(h, w)
    g = np.array(Image.fromarray(g).resize((max(1, int(w * s)), max(1, int(h * s)))))
    out = np.zeros((28, 28), "float32"); h, w = g.shape
    out[(28 - h) // 2:(28 - h) // 2 + h, (28 - w) // 2:(28 - w) // 2 + w] = g / 255.0
    return out[None, ..., None]


def heat_overlay(img, cam):
    h = np.array(Image.fromarray((cam * 255).astype("uint8")).resize(img.size, Image.BILINEAR)) / 255.0
    rgb = np.stack([np.clip(2 * h, 0, 1), np.clip(2 - 2 * np.abs(h - 0.5) * 2, 0, 1) * (h > 0.15),
                    np.clip(1 - 2 * h, 0, 1) * 0.6], -1) * 255
    mix = (0.55 * np.array(img) + 0.45 * rgb).astype("uint8")
    buf = io.BytesIO(); Image.fromarray(mix).save(buf, "JPEG", quality=85)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/digit", methods=["POST"])
def api_digit():
    x = prep_digit(load_img(request.json["image"]))
    if x is None:
        return jsonify(error="empty")
    p = digit_model().predict(x, verbose=0)[0]
    return jsonify(digit=int(p.argmax()), probs=[float(v) for v in p])


@app.route("/api/detect", methods=["POST"])
def api_detect():
    model, cam_model = detector()
    img = load_img(request.json["image"]).convert("RGB")
    arr = preprocess_input(np.array(img.resize((224, 224)), "float32")[None])
    with tf.GradientTape() as tape:
        conv, preds = cam_model(arr)
        top = int(tf.argmax(preds[0]))
        score = preds[:, top]
    grads = tape.gradient(score, conv)
    w = tf.reduce_mean(grads, axis=(1, 2))
    cam = tf.nn.relu(tf.reduce_sum(conv * w[:, None, None, :], -1))[0].numpy()
    cam = cam / (cam.max() + 1e-8)
    res = [{"label": l.replace("_", " "), "score": float(s)} for _, l, s in decode_predictions(preds.numpy(), top=5)[0]]
    return jsonify(results=res, heatmap=heat_overlay(img.resize((320, 240)), np.array(
        Image.fromarray((cam * 255).astype("uint8")).resize((320, 240))) / 255.0))


if __name__ == "__main__":
    digit_model()
    print(">>> Open http://127.0.0.1:5000")
    app.run(debug=False, port=5000)
